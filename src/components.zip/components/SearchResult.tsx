import React, { Component } from "react";
import DefaultItems from "./DefaultItems";
import ItemCard from "./ItemCard";
import { useState } from 'react';

interface Props {
  data: any,
  status: string,
  query: string
}

const SearchResult:React.FC<Props> = ({data, status, query}) => {
  console.log(status);

  if(status == 'No Content'){
    alert("There are no results found");
  }
    return(
      <div className="search-wrapper">
        
        {status.length ?
          <DefaultItems /> :
          <div className="search-wrapper">
            <p className="result-title">Search Result for "<span>{query}</span>"</p>
            <ItemCard data = {data}/>
          </div>
          }
      </div>
    )
  }
  
  export default SearchResult;